# -*- coding: utf-8 -*-
#authors: C. L. Philip CHEN et al., https://www.fst.um.edu.mo/en/staff/pchen.html

import numpy as np
import scipy.io as scio
from BroadLearningSystem import BLS

dataFile = './data/'
trainingMatContent = scio.loadmat(dataFile+'TrainingData.mat')
testingMatContent = scio.loadmat(dataFile+'TestingData.mat')

traindata = np.double(trainingMatContent['TrainingData'][:, :46]/255)
trainlabel = np.double(trainingMatContent['TrainingData'][:, -1])-1
trainlabel = (np.arange(3)==trainlabel[:, None]).astype(np.integer)

testdata = np.double(testingMatContent['TestingData'][:, :46]/255)
testlabel = np.double(testingMatContent['TestingData'][:, -1])-1
testlabel = (np.arange(3)==testlabel[:, None]).astype(np.integer)


N1 = 10  #  # of nodes belong to each window
N2 = 10  #  # of windows -------Feature mapping layer
N3 = 500  #  # of enhancement nodes -----Enhance layer
L = 5    #  # of incremental steps 
# M1 = 50  #  # of adding enhance nodes
s = 0.8  #  shrink coefficient
C = 2**-30  # Regularization coefficient
act = 'tanh'  # the activation function in enhancement layer can be tanh,relu, sigmoid or tansig.

print('-------------------BLS_BASE---------------------------')
test_acc_10, test_time_10, train_acc_10, train_time_10 = [], [], [], []
# run 10 times
for i in range(10):
    print(40*'*'+str(i)+40*'*')
    test_acc, test_time, train_acc_all, train_time=BLS(traindata, trainlabel, testdata, testlabel, s, C, N1, N2, N3, act_function=act)
    test_acc_10.append(test_acc)
    test_time_10.append(test_time)
    train_acc_10.append(train_acc_all)
    train_time_10.append(train_time)
test_acc_10 = np.array(test_acc_10)
test_acc = test_acc_10.mean()  # get the mean of 10 time test_accs.
test_acc_std = np.std(test_acc_10)  # get the std of 10 time test_accs.
test_time_10 = np.array(test_time_10)
test_time = test_time_10.mean()
test_time_std = np.std(test_time_10)
train_acc_10 = np.array(train_acc_10)
train_acc = train_acc_10.mean()  # get the mean of 10 time train_accs.
train_acc_std = np.std(train_acc_10)  # get the std of 10 time train_accs.
train_time = np.array(train_time_10).mean()
print(80*'*')
print('After training 10 times, the average values:\n test_acc:%.4f, test_std:%.4f, train_acc:%.4f, train_time:%.4f' % (test_acc, test_acc_std, train_acc, train_time))
print(80*'*')