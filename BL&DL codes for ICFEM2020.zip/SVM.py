from sklearn import svm
from scipy import io as scio
from sklearn import preprocessing
import time

dataFile = './data/'
trainingMatContent = scio.loadmat(dataFile+'TrainingData.mat')
testingMatContent = scio.loadmat(dataFile+'TestingData.mat')
scaler = preprocessing.MinMaxScaler()

trainvaldata = scaler.fit_transform(trainingMatContent['TrainingData'][:, :46]/255)
trainvallabel = trainingMatContent['TrainingData'][:, -1]-1

testdata = scaler.fit_transform(testingMatContent['TestingData'][:, :46]/255)
testlabel = testingMatContent['TestingData'][:, -1]-1

clf = svm.SVC()
time_start = time.time()
clf.fit(trainvaldata, trainvallabel)  # training step
time_end = time.time()
train_time = time_end-time_start  # the training time
train_pred = clf.predict(trainvaldata)
train_correct = (train_pred == trainvallabel).sum()
train_acc = 1.0*train_correct/trainvaldata.shape[0]  # calculate the train_acc
print('Training acc %.4f, training time %.4f' % (train_acc, train_time))

time_start = time.time()
train_acc = 1.0
pred = clf.predict(testdata)
correct = (pred == testlabel).sum()
test_acc = 1.0*correct/testdata.shape[0]  # calculate the test_acc
test_time = time.time()-time_start
print('Testing acc %.4f, testing time: %.4f' % (test_acc, test_time))
