import matplotlib.pyplot as plt

x = [50, 100, 150, 200, 250, 300, 350, 400, 450, 500]

y_bls = [0.7392, 0.7301, 0.7489, 0.7476, 0.7486, 0.7511, 0.7490, 0.7510, 0.7497, 0.7508]
y_mlp = [0.9173, 0.9168, 0.9176, 0.9210, 0.9176, 0.9200, 0.9211, 0.9248, 0.9184, 0.9186]

plt.ylim(0.70, 1)
plt.ylabel('Test accuracy')
plt.xlabel('nodes')
plt.plot(x, y_bls, color='skyblue', label='$BLS$')
plt.plot(x, y_mlp, color='green', label='$MLP$')
plt.legend()
plt.show()
print()
