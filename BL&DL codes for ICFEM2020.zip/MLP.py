from scipy import io as scio
import torch
from torch import nn
import sys
from sklearn import preprocessing


class Logger(object):
    def __init__(self, fileN='Default.log'):
        self.terminal = sys.stdout
        self.log = open(fileN, "w")

    def write(self, message):
        self.terminal.write(message)
        self.log.write(message)

    def flush(self):
        pass


class DATA_LOADER(object):
    def __init__(self, finalTrain=False):
        dataFile = './data/'
        trainingMatContent = scio.loadmat(dataFile+'TrainingData.mat')
        testingMatContent = scio.loadmat(dataFile+'TestingData.mat')
        scaler = preprocessing.MinMaxScaler()

        self.trainvaldata = torch.from_numpy(scaler.fit_transform(trainingMatContent['TrainingData'][:, :46]/255)).float()
        self.trainvallabel = torch.from_numpy(trainingMatContent['TrainingData'][:, -1]-1).long()
        if finalTrain:
            self.traindata = self.trainvaldata
            self.trainlabel = self.trainvallabel
        else:
            ind = int(self.trainvaldata.shape[0]*0.7)
            self.traindata = self.trainvaldata[:ind, :]
            self.trainlabel = self.trainvallabel[:ind]
            self.valdata = self.trainvaldata[ind:, :]
            self.vallabel = self.trainvallabel[ind:]

        self.testdata = torch.from_numpy(scaler.fit_transform(testingMatContent['TestingData'][:, :46]/255)).float()
        self.testlabel = torch.from_numpy(testingMatContent['TestingData'][:, -1]-1).long()
        self.ntrain = self.traindata.shape[0]
        self.ntest = self.testdata.shape[0]

    def next_batch(self, batch_size):
        idx = torch.randperm(self.traindata.shape[0])[0:batch_size]  # ntrain:val=7057
        batch_feature = self.traindata[idx]
        batch_label = self.trainlabel[idx]
        return batch_feature, batch_label


class LINEAR_LOGSOFTMAX(torch.nn.Module):
    def __init__(self, act='relu', enhanceNode=500):
        super(LINEAR_LOGSOFTMAX, self).__init__()
        self.fc0 = nn.Linear(46, 100)
        self.fc1 = nn.Linear(100, enhanceNode)
        self.fc2 = nn.Linear(enhanceNode, 3)
        if act == 'relu':
            self.act = nn.ReLU(inplace=True)
        elif act=='sigmoid':
            self.act = nn.Sigmoid()
        elif act == 'tanh':
            self.act = nn.Tanh()
        self.logic = nn.LogSoftmax(dim=1)

    def forward(self, x):
        x = self.act(self.fc0(x))
        x = self.act(self.fc1(x))
        x = self.fc2(x)
        o = self.logic(x)
        return o


def val(test_X, test_label, model, device):
    start = 0
    ntest = test_X.size()[0]
    predicted_label = torch.LongTensor(test_label.size())
    with torch.no_grad():
        for i in range(0, ntest, batch_size):
            end = min(ntest, start + batch_size)
            output = model(test_X[start:end].to(device))
            _, predicted_label[start:end] = torch.max(output.data, 1)
            start = end
        i = (predicted_label == test_label).sum()
        acc = float(i)/test_label.size(0)
    return acc


if __name__ == '__main__':
    import os
    import time
    torch.cuda.set_device(0)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    act = 'tanh'  # the activation function
    optimer = 'Adam'  # you can change the optimer to be Adam, SGD or RMSprop.
    enhanceNode = 500  # the node of second hidden layer
    LEARNING_RATE = 0.0003  # the learning rate

    # store the training logger
    os.makedirs('./log_act', exist_ok=True)
    sys.stdout = Logger(
        'log_act/(' + act + ')' + time.strftime("%Y-%m-%d %H:%M:%S", time.localtime()) + '.log')
    with open('MLP.py') as f:
        contents = f.read()
        print(contents)
    f.close()

    # determine the epoch
    data = DATA_LOADER(finalTrain=False)
    model = LINEAR_LOGSOFTMAX(act=act, enhanceNode=enhanceNode).to(device)
    if optimer == 'Adam':
        optim = torch.optim.Adam(model.parameters(), lr=LEARNING_RATE, weight_decay=1e-5)
    elif optimer == 'SGD':
        optim = torch.optim.SGD(model.parameters(), lr=LEARNING_RATE, momentum=0.9, weight_decay=1e-5)
    elif optimer == 'RMSprop':
        optim = torch.optim.RMSprop(model.parameters(), lr=LEARNING_RATE, weight_decay=1e-5)
    criterion = nn.NLLLoss().to(device)
    batch_size = 32
    best_val_acc = 0.0
    for epoch in range(500):
        for i in range(0, data.ntrain, batch_size):
            optim.zero_grad()
            batch_input, batch_label = data.next_batch(batch_size)
            batch_input, batch_label = batch_input.to(device), batch_label.to(device)
            output = model(batch_input)
            loss = criterion(output, batch_label)
            loss.backward()
            optim.step()
        print('epoch:%d, train_loss:%.4f' % (epoch, loss))
        model.eval()
        acc = val(data.valdata.to(device), data.vallabel, model, device)
        if acc>best_val_acc:
            best_val_acc = acc
            best_epoch = epoch
        print('epoch:%d, val_acc %.4f ' % (epoch, acc))
        model.train()

    # final_train: add the validation data to the training dataset,and set the epoch as best_epoch
    data = DATA_LOADER(finalTrain=True)
    model = LINEAR_LOGSOFTMAX(act=act, enhanceNode=enhanceNode).to(device)
    if optimer == 'Adam':
        optim = torch.optim.Adam(model.parameters(), lr=LEARNING_RATE, weight_decay=1e-5)
    elif optimer == 'SGD':
        optim = torch.optim.SGD(model.parameters(), lr=LEARNING_RATE, momentum=0.9, weight_decay=1e-5)
    elif optimer == 'RMSprop':
        optim = torch.optim.RMSprop(model.parameters(), lr=LEARNING_RATE, weight_decay=1e-5)

    # begin to timekeep of training time
    time_start = time.time()
    for epoch in range(best_epoch):
        for i in range(0, data.ntrain, batch_size):
            optim.zero_grad()
            batch_input, batch_label = data.next_batch(batch_size)
            batch_input, batch_label = batch_input.to(device), batch_label.to(device)
            output = model(batch_input)
            loss = criterion(output, batch_label)
            loss.backward()
            optim.step()
        print('epoch:%d, loss:%.4f' % (epoch, loss))
    time_end = time.time()
    time_last = time_end - time_start
    print('[%d, %d] train_loss:%.4f train_time:%.4f' % (epoch, i, loss, time_last))
    model.eval()
    acc = val(data.traindata.to(device), data.trainlabel, model, device)  # calculate the train_acc
    print('epoch:%d, train_acc %.4f ' % (epoch, acc))

    # begin to timekeep the testing time
    time_start = time.time()
    acc = val(data.testdata.to(device), data.testlabel, model, device)  # calculation the test_acc
    time_end = time.time()
    test_time = time_end - time_start
    print('epoch:%d, test_acc %.4f, test_time: %.4f ' % (epoch, acc, test_time))
    model.train()