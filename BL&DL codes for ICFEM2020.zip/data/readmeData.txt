Training data: 25095*47
attributes: column No.1 - No.46
label: 3 classes, column No. 47.


Testing data: 6276*47
attributes: column No.1 - No.46
label: 3 classes, column No. 47.
